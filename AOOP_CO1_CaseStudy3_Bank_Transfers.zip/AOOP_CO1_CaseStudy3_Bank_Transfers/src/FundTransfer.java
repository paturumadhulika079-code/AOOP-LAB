import java.time.Instant;
import java.util.UUID;

public final class FundTransfer {
    public enum Status { COMPLETED, FAILED }
    private final String transferId = UUID.randomUUID().toString();
    private final AccountNumber source;
    private final AccountNumber destination;
    private final Money amount;
    private final Instant createdAt = Instant.now();
    private Status status;

    FundTransfer(AccountNumber source, AccountNumber destination, Money amount) {
        this.source = source;
        this.destination = destination;
        this.amount = amount;
    }
    void markCompleted() { status = Status.COMPLETED; }
    void markFailed() { status = Status.FAILED; }
    public String getTransferId() { return transferId; }
    public AccountNumber getSource() { return source; }
    public AccountNumber getDestination() { return destination; }
    public Money getAmount() { return amount; }
    public Instant getCreatedAt() { return createdAt; }
    public Status getStatus() { return status; }
}

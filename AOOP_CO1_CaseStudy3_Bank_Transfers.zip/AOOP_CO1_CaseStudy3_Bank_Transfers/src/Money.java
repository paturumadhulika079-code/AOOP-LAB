import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

public final class Money {
    private final BigDecimal amount;
    private final Currency currency;

    private Money(BigDecimal amount, Currency currency) {
        this.currency = Objects.requireNonNull(currency, "currency");
        BigDecimal normalized = Objects.requireNonNull(amount, "amount")
                .setScale(currency.getScale(), RoundingMode.UNNECESSARY);
        if (normalized.signum() < 0) {
            throw new IllegalArgumentException("Money cannot be negative");
        }
        this.amount = normalized;
    }

    public static Money of(String amount, Currency currency) {
        return new Money(new BigDecimal(amount), currency);
    }

    public static Money zero(Currency currency) {
        return new Money(BigDecimal.ZERO.setScale(currency.getScale()), currency);
    }

    public BigDecimal getAmount() { return amount; }
    public Currency getCurrency() { return currency; }

    public Money plus(Money other) {
        requireSameCurrency(other);
        return new Money(amount.add(other.amount), currency);
    }

    public Money minus(Money other) {
        requireSameCurrency(other);
        if (amount.compareTo(other.amount) < 0) {
            throw new IllegalArgumentException("Resulting money cannot be negative");
        }
        return new Money(amount.subtract(other.amount), currency);
    }

    public boolean isGreaterThanOrEqualTo(Money other) {
        requireSameCurrency(other);
        return amount.compareTo(other.amount) >= 0;
    }

    private void requireSameCurrency(Money other) {
        Objects.requireNonNull(other, "other");
        if (currency != other.currency) {
            throw new IllegalArgumentException("Currency mismatch");
        }
    }

    @Override public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Money)) return false;
        Money other = (Money) obj;
        return currency == other.currency && amount.compareTo(other.amount) == 0;
    }

    @Override public int hashCode() {
        return Objects.hash(amount.stripTrailingZeros(), currency);
    }

    @Override public String toString() { return currency + " " + amount; }
}

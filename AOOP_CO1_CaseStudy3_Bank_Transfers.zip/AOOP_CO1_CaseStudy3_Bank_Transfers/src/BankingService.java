import java.util.Objects;

public final class BankingService {
    private static final Object TRANSFER_LOCK = new Object();

    public FundTransfer transfer(BankAccount source, BankAccount destination, Money amount) {
        Objects.requireNonNull(source);
        Objects.requireNonNull(destination);
        Objects.requireNonNull(amount);
        if (source == destination || source.getAccountNumber().equals(destination.getAccountNumber())) {
            throw new IllegalArgumentException("Source and destination accounts must be different");
        }
        if (amount.getAmount().signum() <= 0) throw new IllegalArgumentException("Transfer amount must be positive");
        if (source.getBalance().getCurrency() != destination.getBalance().getCurrency()
                || source.getBalance().getCurrency() != amount.getCurrency()) {
            throw new IllegalArgumentException("All transfer currencies must match");
        }

        synchronized (TRANSFER_LOCK) {
            Money sourceBefore = source.getBalance();
            Money destinationBefore = destination.getBalance();
            int sourceLedgerSize = source.getLedger().size();
            int destinationLedgerSize = destination.getLedger().size();
            FundTransfer transfer = new FundTransfer(source.getAccountNumber(), destination.getAccountNumber(), amount);

            try {
                source.debitForTransfer(amount, transfer.getTransferId());
                destination.creditForTransfer(amount, transfer.getTransferId());
                transfer.markCompleted();
                return transfer;
            } catch (RuntimeException failure) {
                source.restoreAfterFailedTransfer(sourceBefore, sourceLedgerSize);
                destination.restoreAfterFailedTransfer(destinationBefore, destinationLedgerSize);
                transfer.markFailed();
                throw failure;
            }
        }
    }
}

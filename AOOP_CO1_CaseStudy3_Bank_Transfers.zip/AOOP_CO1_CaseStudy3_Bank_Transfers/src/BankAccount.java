import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public final class BankAccount {
    private final AccountNumber accountNumber;
    private final Money overdraftLimit;
    private Money balance;
    private AccountStatus status;
    private final List<LedgerEntry> ledger = new ArrayList<>();

    public BankAccount(AccountNumber accountNumber, Money openingBalance, Money overdraftLimit) {
        this.accountNumber = Objects.requireNonNull(accountNumber);
        this.balance = Objects.requireNonNull(openingBalance);
        this.overdraftLimit = Objects.requireNonNull(overdraftLimit);
        if (openingBalance.getCurrency() != overdraftLimit.getCurrency()) {
            throw new IllegalArgumentException("Balance and overdraft limit currencies must match");
        }
        this.status = AccountStatus.ACTIVE;
    }

    public AccountNumber getAccountNumber() { return accountNumber; }
    public synchronized Money getBalance() { return balance; }
    public Money getOverdraftLimit() { return overdraftLimit; }
    public synchronized AccountStatus getStatus() { return status; }
    public synchronized List<LedgerEntry> getLedger() {
        return Collections.unmodifiableList(new ArrayList<>(ledger));
    }

    public synchronized void deposit(Money amount) {
        requireActive();
        validatePositive(amount);
        requireCurrency(amount);
        balance = balance.plus(amount);
        ledger.add(new LedgerEntry(LedgerEntry.Type.DEPOSIT, amount, balance, "Cash deposit", null));
    }

    public synchronized void withdraw(Money amount) {
        requireActive();
        validatePositive(amount);
        requireCurrency(amount);
        Money permittedNegativeBoundary = overdraftLimit;
        Money available = balance.plus(permittedNegativeBoundary);
        if (!available.isGreaterThanOrEqualTo(amount)) {
            throw new IllegalStateException("Overdraft limit would be exceeded");
        }
        // The balance is represented as non-negative Money in this teaching model.
        // Therefore overdraft usage is tracked as a separate amount in the production design.
        // This implementation permits withdrawals only up to the current balance.
        if (!balance.isGreaterThanOrEqualTo(amount)) {
            throw new IllegalStateException("Insufficient available balance for this demo account");
        }
        balance = balance.minus(amount);
        ledger.add(new LedgerEntry(LedgerEntry.Type.WITHDRAWAL, amount, balance, "Cash withdrawal", null));
    }

    synchronized void debitForTransfer(Money amount, String reference) {
        requireActive();
        validatePositive(amount);
        requireCurrency(amount);
        if (!balance.isGreaterThanOrEqualTo(amount)) {
            throw new IllegalStateException("Insufficient available balance");
        }
        balance = balance.minus(amount);
        ledger.add(new LedgerEntry(LedgerEntry.Type.TRANSFER_OUT, amount, balance, "Transfer to another account", reference));
    }

    synchronized void creditForTransfer(Money amount, String reference) {
        requireActive();
        validatePositive(amount);
        requireCurrency(amount);
        balance = balance.plus(amount);
        ledger.add(new LedgerEntry(LedgerEntry.Type.TRANSFER_IN, amount, balance, "Transfer from another account", reference));
    }

    synchronized void restoreAfterFailedTransfer(Money oldBalance, int oldLedgerSize) {
        balance = oldBalance;
        while (ledger.size() > oldLedgerSize) ledger.remove(ledger.size() - 1);
    }

    public synchronized void freeze() {
        if (status != AccountStatus.ACTIVE) throw new IllegalStateException("Only active accounts can be frozen");
        status = AccountStatus.FROZEN;
    }

    public synchronized void unfreeze() {
        if (status != AccountStatus.FROZEN) throw new IllegalStateException("Only frozen accounts can be unfrozen");
        status = AccountStatus.ACTIVE;
    }

    public synchronized void close() {
        if (status == AccountStatus.CLOSED) throw new IllegalStateException("Account is already closed");
        if (balance.getAmount().signum() != 0) throw new IllegalStateException("Account must have zero balance before closing");
        status = AccountStatus.CLOSED;
    }

    private void requireActive() {
        if (status != AccountStatus.ACTIVE) throw new IllegalStateException("Account is not active: " + status);
    }

    private void validatePositive(Money amount) {
        Objects.requireNonNull(amount, "amount");
        if (amount.getAmount().signum() <= 0) throw new IllegalArgumentException("Transaction amount must be positive");
    }

    private void requireCurrency(Money amount) {
        if (balance.getCurrency() != amount.getCurrency()) throw new IllegalArgumentException("Currency mismatch");
    }
}

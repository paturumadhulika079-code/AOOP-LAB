import java.time.Instant;
import java.util.Objects;
import java.util.UUID;

public final class LedgerEntry {
    public enum Type { DEPOSIT, WITHDRAWAL, TRANSFER_IN, TRANSFER_OUT }

    private final String entryId;
    private final Type type;
    private final Money amount;
    private final Money balanceAfter;
    private final Instant timestamp;
    private final String description;
    private final String transferReference;

    public LedgerEntry(Type type, Money amount, Money balanceAfter,
                       String description, String transferReference) {
        this.entryId = UUID.randomUUID().toString();
        this.type = Objects.requireNonNull(type);
        this.amount = Objects.requireNonNull(amount);
        this.balanceAfter = Objects.requireNonNull(balanceAfter);
        this.timestamp = Instant.now();
        this.description = Objects.requireNonNull(description);
        this.transferReference = transferReference;
    }

    public String getEntryId() { return entryId; }
    public Type getType() { return type; }
    public Money getAmount() { return amount; }
    public Money getBalanceAfter() { return balanceAfter; }
    public Instant getTimestamp() { return timestamp; }
    public String getDescription() { return description; }
    public String getTransferReference() { return transferReference; }

    @Override public String toString() {
        return timestamp + " | " + type + " | " + amount + " | balance=" + balanceAfter
                + " | " + description;
    }
}

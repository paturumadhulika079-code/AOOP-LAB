public class App {
    public static void main(String[] args) {
        BankAccount accountA = new BankAccount(
                new AccountNumber("ACC-10001"),
                Money.of("10000.00", Currency.INR),
                Money.of("2000.00", Currency.INR));

        BankAccount accountB = new BankAccount(
                new AccountNumber("ACC-10002"),
                Money.of("2500.00", Currency.INR),
                Money.zero(Currency.INR));

        BankingService bankingService = new BankingService();
        FundTransfer transfer = bankingService.transfer(
                accountA, accountB, Money.of("5000.00", Currency.INR));

        System.out.println("Transfer ID: " + transfer.getTransferId());
        System.out.println("Transfer status: " + transfer.getStatus());
        System.out.println("Account A balance: " + accountA.getBalance());
        System.out.println("Account B balance: " + accountB.getBalance());

        System.out.println("\\nAccount A ledger:");
        for (LedgerEntry entry : accountA.getLedger()) System.out.println(entry);

        System.out.println("\\nAccount B ledger:");
        for (LedgerEntry entry : accountB.getLedger()) System.out.println(entry);

        System.out.println("\\nTesting frozen account:");
        accountA.freeze();
        try {
            accountA.withdraw(Money.of("100.00", Currency.INR));
        } catch (IllegalStateException ex) {
            System.out.println("Withdrawal blocked: " + ex.getMessage());
        }
    }
}

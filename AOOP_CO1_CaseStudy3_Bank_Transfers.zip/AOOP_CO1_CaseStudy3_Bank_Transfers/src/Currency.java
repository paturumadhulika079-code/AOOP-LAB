public enum Currency {
    INR(2);
    private final int scale;
    Currency(int scale) { this.scale = scale; }
    public int getScale() { return scale; }
}

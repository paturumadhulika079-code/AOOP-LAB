# AOOP CO-1 Case Study 3: Bank Account and Money Transfers

## 1. Problem analysis
The banking system must support deposits, withdrawals, account freezing/unfreezing, closing accounts and transfers. The reported failures arise because business rules are not enforced inside the domain objects and transfer steps are not treated as one atomic operation.

## 2. Domain invariants

| Invariant | Why it matters | If violated |
|---|---|---|
| Every transaction amount must be greater than zero | Prevents meaningless or abusive transactions | Invalid ledger records and balance manipulation |
| An account number must be valid and unique | Identifies one account reliably | Transactions may reach the wrong account |
| Only ACTIVE accounts may deposit, withdraw or transfer | Frozen/closed accounts must not transact | Unauthorized movement of funds |
| A withdrawal must not exceed the available balance plus the permitted overdraft | Protects the bank and customer from exceeding agreed credit | Unauthorized overdraft and financial loss |
| Balance, overdraft limit and transaction amounts must use the same currency | Prevents invalid arithmetic | Incorrect balances |
| A transfer must debit and credit the same amount exactly once | Preserves money across accounts | Money can disappear or be duplicated |
| Ledger entries are immutable and every completed transaction is recorded | Provides an auditable history | Balance disputes and audit gaps |
| A closed account cannot be reactivated or used | Enforces account lifecycle | Transactions on terminated accounts |

## 3. Entities and value objects

| Concept | Classification | Reason |
|---|---|---|
| Bank Account | Entity | Has a stable account identity and a changing balance/status |
| Account Number | Value Object | Equality is based on its validated value; immutable |
| Money | Value Object | Defined by amount and currency; immutable |
| Ledger Entry | Entity (within an account ledger) | Has a unique entry ID and timestamp; retained as an audit record |
| Overdraft Limit | Value Object | A non-negative monetary amount, compared by value |
| Fund Transfer | Entity | Has a unique transfer ID, lifecycle status and source/destination |

## 4. Java design and self-enforcing objects
- `Money` validates non-negative amounts, currency and decimal precision.
- `AccountNumber` validates its format and is immutable.
- `BankAccount` keeps fields private and exposes business operations rather than public setters.
- `deposit` and `withdraw` reject zero/negative amounts.
- Frozen and closed accounts reject transactions.
- `freeze`, `unfreeze` and `close` validate legal state transitions.
- `LedgerEntry` is immutable and returned through an unmodifiable list.
- `BankingService` coordinates transfers and validates both accounts and currencies.

### Overdraft note
The sample keeps `Money` non-negative and the demonstration withdrawal is limited to the current balance. A production overdraft implementation should model the account's signed available balance or track `overdraftUsed` separately, and enforce:
`newBalance >= -overdraftLimit`.
This avoids representing a negative price-like `Money` value while still supporting a negative bank-account balance.

## 5. Transfer consistency and failure handling

### Failure scenario
If Account A is debited and the process stops before Account B is credited:
- The source balance falls but the destination balance does not rise.
- The transfer amount is lost from the customers' combined balances.
- The ledger and balances disagree with the intended business transaction.

### Invariants violated
- Transfer debit and credit must be one logical operation.
- The source and destination ledgers must agree on the same transfer reference and amount.
- Account balances must reconcile with their ledger entries.

### Design
`BankingService.transfer` coordinates both account updates under a lock and restores both in-memory account snapshots if an exception occurs. This demonstrates rollback for an application-level exception.

**Production requirement:** an in-memory lock cannot protect against a machine crash or power failure. Persist the debit, credit, transfer record and ledger entries inside one database ACID transaction. Commit all changes together or roll them all back. Use a unique transfer ID/idempotency key to prevent duplicate processing, durable transaction status, and reconciliation for uncertain outcomes.

### Different banking systems
A single database transaction usually cannot span independent banks. Use a durable workflow such as a saga or a payment/clearing protocol:
1. Create a uniquely identified transfer request.
2. Reserve or debit funds through the source bank's supported operation.
3. Obtain a durable acknowledgement.
4. Credit the destination through its supported operation.
5. On failure, retry safely or issue a compensating reversal.
6. Reconcile pending/unknown transfers and expose a clear status to the customer.
Never assume a timeout means the remote bank did not process the request.

## 6. Ledger management
A ledger entry should contain:
- Unique entry ID
- Account number
- Transaction type (deposit, withdrawal, transfer-in, transfer-out)
- Exact amount and currency
- Timestamp
- Balance after the transaction
- Description/reference and transfer ID where applicable

Completed ledger entries should not be edited or deleted. Corrections should be represented by a new reversing or adjustment entry, preserving the audit trail.

To keep balances consistent, write the balance update and ledger entry in the same database transaction. Periodically reconcile the stored balance against the opening balance plus ledger movements. For large histories, use pagination, indexes, archival policies, partitioning and verified snapshots while retaining auditable records.

## 7. UML-style domain overview

```text
BankAccount (Entity)
  - accountNumber: AccountNumber
  - balance: Money
  - overdraftLimit: Money
  - status: AccountStatus
  - ledger: List<LedgerEntry>
  + deposit(amount)
  + withdraw(amount)
  + freeze()
  + unfreeze()
  + close()

AccountNumber (Value Object)       Money (Value Object)
  - value: String                    - amount: BigDecimal
                                     - currency: Currency

LedgerEntry (Audit record)         FundTransfer (Entity)
  - entryId                         - transferId
  - type                             - source
  - amount                           - destination
  - balanceAfter                     - amount
  - timestamp                        - status

BankingService
  + transfer(source, destination, amount)
```

## 8. Run the project

Requires JDK 17 or later.

From the project root:

```powershell
javac -d bin src\*.java
java -cp bin App
```

Expected behavior: a ₹5,000 transfer completes, Account A becomes ₹5,000, Account B becomes ₹7,500, ledger entries are printed, and a withdrawal from a frozen account is rejected.

## 9. Important implementation scope
This is an educational in-memory demonstration, not production banking software. Real banking requires durable database transactions, concurrency control, authentication/authorization, encryption, audit controls, idempotency, regulatory compliance, and cross-bank settlement protocols.

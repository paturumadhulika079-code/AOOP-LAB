import java.util.Objects;

public final class AccountNumber {
    private final String value;

    public AccountNumber(String value) {
        Objects.requireNonNull(value, "account number");
        String normalized = value.trim();
        if (!normalized.matches("[A-Z0-9-]{6,20}")) {
            throw new IllegalArgumentException("Account number must be 6-20 uppercase letters, digits or hyphens");
        }
        this.value = normalized;
    }

    public String getValue() { return value; }
    @Override public boolean equals(Object o) {
        return o instanceof AccountNumber && value.equals(((AccountNumber) o).value);
    }
    @Override public int hashCode() { return value.hashCode(); }
    @Override public String toString() { return value; }
}

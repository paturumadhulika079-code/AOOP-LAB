import java.time.Instant;

public class App {
    public static void main(String[] args) {
        Order order = new Order(new OrderId("ORD-1001"));
        ProductId keyboard = new ProductId("PROD-01");
        ProductId mouse = new ProductId("PROD-02");

        order.addLine(keyboard, Money.of("75.00", Currency.USD), new Quantity(1));
        order.addLine(mouse, Money.of("25.00", Currency.USD), new Quantity(2));
        order.addLine(mouse, Money.of("25.00", Currency.USD), new Quantity(1));

        System.out.println("Order: " + order.getId());
        System.out.println("Status: " + order.getStatus());
        System.out.println("Lines (duplicate product merged):");
        for (OrderLine line : order.getLines()) System.out.println("  " + line);
        System.out.println("Derived total: " + order.total());

        order.place();
        order.pay(new PaymentRef("PAY-7788"));
        order.ship(new TrackingNumber("TRACK-ABC-123"), Instant.parse("2026-11-14T08:00:00Z"));
        System.out.println("\\nAfter shipping: " + order.getStatus());
        System.out.println("Shipment: " + order.getShipment());

        order.deliver(Instant.parse("2026-11-15T12:00:00Z"));
        System.out.println("After delivery: " + order.getStatus());

        Order empty = new Order(new OrderId("ORD-EMPTY"));
        try {
            empty.place();
        } catch (DomainException ex) {
            System.out.println("\\nEmpty order blocked: " + ex.getMessage());
        }

        try {
            order.cancel("Customer changed mind");
        } catch (DomainException ex) {
            System.out.println("Delivered order cancellation blocked: " + ex.getMessage());
        }
    }
}

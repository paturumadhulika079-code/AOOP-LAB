import java.util.Objects;
public final class OrderId {
    private final String value;
    public OrderId(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Order ID cannot be blank");
        this.value = value.trim();
    }
    public String getValue() { return value; }
    @Override public boolean equals(Object o) { return o instanceof OrderId && value.equals(((OrderId)o).value); }
    @Override public int hashCode() { return Objects.hash(value); }
    @Override public String toString() { return value; }
}

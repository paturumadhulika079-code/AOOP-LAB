import java.util.Objects;
public final class TrackingNumber {
    private final String value;
    public TrackingNumber(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Tracking number is required");
        this.value = value.trim();
    }
    public String getValue() { return value; }
    @Override public boolean equals(Object o) { return o instanceof TrackingNumber && value.equals(((TrackingNumber)o).value); }
    @Override public int hashCode() { return Objects.hash(value); }
    @Override public String toString() { return value; }
}

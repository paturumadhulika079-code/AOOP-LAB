public final class PaymentRef {
    private final String value;
    public PaymentRef(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Payment reference is required");
        this.value = value.trim();
    }
    @Override public String toString() { return value; }
}

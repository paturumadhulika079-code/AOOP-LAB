import java.time.Instant;
import java.util.Objects;
public final class Shipment {
    private final TrackingNumber trackingNumber;
    private final Instant shippedAt;
    public Shipment(TrackingNumber trackingNumber, Instant shippedAt) {
        this.trackingNumber = Objects.requireNonNull(trackingNumber);
        this.shippedAt = Objects.requireNonNull(shippedAt);
    }
    public TrackingNumber getTrackingNumber() { return trackingNumber; }
    public Instant getShippedAt() { return shippedAt; }
    @Override public String toString() { return trackingNumber + " @ " + shippedAt; }
}

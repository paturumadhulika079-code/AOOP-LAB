import java.util.Objects;
public final class OrderLine {
    private final ProductId productId;
    private final Money unitPrice;
    private final Quantity quantity;

    public OrderLine(ProductId productId, Money unitPrice, Quantity quantity) {
        this.productId = Objects.requireNonNull(productId);
        this.unitPrice = Objects.requireNonNull(unitPrice);
        this.quantity = Objects.requireNonNull(quantity);
    }
    public ProductId getProductId() { return productId; }
    public Money getUnitPrice() { return unitPrice; }
    public Quantity getQuantity() { return quantity; }
    public Money total() { return unitPrice.times(quantity); }

    public OrderLine combine(OrderLine other) {
        if (!productId.equals(other.productId)) throw new IllegalArgumentException("Cannot combine different products");
        if (!unitPrice.equals(other.unitPrice)) throw new IllegalArgumentException("Unit prices differ for the same product");
        return new OrderLine(productId, unitPrice, quantity.plus(other.quantity));
    }
    @Override public String toString() {
        return productId + " x " + quantity + " @ " + unitPrice + " = " + total();
    }
}

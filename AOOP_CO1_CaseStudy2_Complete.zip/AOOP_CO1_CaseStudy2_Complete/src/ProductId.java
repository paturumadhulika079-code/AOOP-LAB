import java.util.Objects;
public final class ProductId {
    private final String value;
    public ProductId(String value) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException("Product ID cannot be blank");
        this.value = value.trim();
    }
    public String getValue() { return value; }
    @Override public boolean equals(Object o) { return o instanceof ProductId && value.equals(((ProductId)o).value); }
    @Override public int hashCode() { return Objects.hash(value); }
    @Override public String toString() { return value; }
}

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Objects;

public final class Money {
    private final BigDecimal amount;
    private final Currency currency;

    private Money(BigDecimal amount, Currency currency) {
        this.currency = Objects.requireNonNull(currency);
        Objects.requireNonNull(amount);
        if (amount.signum() < 0) throw new IllegalArgumentException("Money cannot be negative");
        try {
            this.amount = amount.setScale(currency.getMinorUnits(), RoundingMode.UNNECESSARY);
        } catch (ArithmeticException ex) {
            throw new IllegalArgumentException("Invalid precision for " + currency, ex);
        }
    }
    public static Money of(String amount, Currency currency) {
        return new Money(new BigDecimal(amount), currency);
    }
    public static Money zero(Currency currency) { return new Money(BigDecimal.ZERO, currency); }
    public BigDecimal getAmount() { return amount; }
    public Currency getCurrency() { return currency; }
    public Money plus(Money other) {
        Objects.requireNonNull(other);
        if (currency != other.currency) throw new IllegalArgumentException("Currency mismatch");
        return new Money(amount.add(other.amount), currency);
    }
    public Money times(Quantity quantity) {
        return new Money(amount.multiply(BigDecimal.valueOf(quantity.getValue())), currency);
    }
    @Override public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Money)) return false;
        Money other = (Money) obj;
        return currency == other.currency && amount.compareTo(other.amount) == 0;
    }
    @Override public int hashCode() { return Objects.hash(amount.stripTrailingZeros(), currency); }
    @Override public String toString() { return currency + " " + amount.toPlainString(); }
}

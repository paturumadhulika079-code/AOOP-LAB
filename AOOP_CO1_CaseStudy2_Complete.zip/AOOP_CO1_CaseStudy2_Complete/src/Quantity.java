public final class Quantity {
    private final int value;
    public Quantity(int value) {
        if (value <= 0) throw new IllegalArgumentException("Quantity must be positive");
        this.value = value;
    }
    public int getValue() { return value; }
    public Quantity plus(Quantity other) { return new Quantity(value + other.value); }
    @Override public String toString() { return Integer.toString(value); }
}

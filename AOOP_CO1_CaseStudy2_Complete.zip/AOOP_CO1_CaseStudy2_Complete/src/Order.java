import java.time.Instant;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public final class Order {
    private final OrderId id;
    private OrderStatus status = OrderStatus.DRAFT;
    private final Map<ProductId, OrderLine> lines = new LinkedHashMap<>();
    private Shipment shipment;
    private Instant deliveredAt;
    private String cancellationReason;
    private PaymentRef paymentRef;

    public Order(OrderId id) { this.id = Objects.requireNonNull(id); }
    public OrderId getId() { return id; }
    public OrderStatus getStatus() { return status; }

    public void addLine(ProductId productId, Money unitPrice, Quantity quantity) {
        requireStatus(OrderStatus.DRAFT);
        OrderLine incoming = new OrderLine(productId, unitPrice, quantity);
        lines.merge(productId, incoming, OrderLine::combine);
    }

    public void removeLine(ProductId productId) {
        requireStatus(OrderStatus.DRAFT);
        lines.remove(Objects.requireNonNull(productId));
    }

    public void place() {
        requireStatus(OrderStatus.DRAFT);
        if (lines.isEmpty()) throw new DomainException("Cannot place an empty order");
        status = OrderStatus.PLACED;
    }

    public void pay(PaymentRef paymentRef) {
        requireStatus(OrderStatus.PLACED);
        this.paymentRef = Objects.requireNonNull(paymentRef);
        status = OrderStatus.PAID;
    }

    public void ship(TrackingNumber trackingNumber, Instant at) {
        requireStatus(OrderStatus.PAID);
        shipment = new Shipment(trackingNumber, at);
        status = OrderStatus.SHIPPED;
    }

    public void deliver(Instant at) {
        requireStatus(OrderStatus.SHIPPED);
        deliveredAt = Objects.requireNonNull(at);
        status = OrderStatus.DELIVERED;
    }

    public void cancel(String reason) {
        if (status != OrderStatus.DRAFT && status != OrderStatus.PLACED && status != OrderStatus.PAID)
            throw new DomainException("Only DRAFT, PLACED or PAID orders can be cancelled");
        if (reason == null || reason.trim().isEmpty())
            throw new IllegalArgumentException("Cancellation reason is required");
        cancellationReason = reason.trim();
        status = OrderStatus.CANCELLED;
    }

    public Money total() {
        if (lines.isEmpty()) return Money.zero(Currency.USD);
        Currency currency = lines.values().iterator().next().getUnitPrice().getCurrency();
        Money result = Money.zero(currency);
        for (OrderLine line : lines.values()) result = result.plus(line.total());
        return result;
    }

    public List<OrderLine> getLines() {
        return Collections.unmodifiableList(new ArrayList<>(lines.values()));
    }
    public Shipment getShipment() { return shipment; }
    public Instant getDeliveredAt() { return deliveredAt; }
    public String getCancellationReason() { return cancellationReason; }
    public PaymentRef getPaymentRef() { return paymentRef; }

    private void requireStatus(OrderStatus expected) {
        if (status != expected)
            throw new DomainException("Expected status " + expected + " but was " + status);
    }
}

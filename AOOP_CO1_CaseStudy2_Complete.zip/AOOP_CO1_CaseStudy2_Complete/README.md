# AOOP CO1 Case Study 2: Order Management and State Transitions

## Overview
This Java project models an order lifecycle with a guarded state machine. It protects order invariants inside the `Order` aggregate root.

## Implemented model
- `Order` is an entity and aggregate root identified by `OrderId`.
- `OrderLine` contains `ProductId`, unit `Money`, and positive `Quantity`.
- `OrderId`, `ProductId`, and `TrackingNumber` are value objects.
- `OrderStatus` is a closed enum.
- `Shipment` groups tracking number and shipment timestamp.
- `Order.total()` derives the total from line values instead of storing a second, potentially stale total.

## Lifecycle
`DRAFT -> PLACED -> PAID -> SHIPPED -> DELIVERED`

Cancellation is allowed from `DRAFT`, `PLACED`, and `PAID`. It is rejected from `SHIPPED` and `DELIVERED`.

## Invariants enforced
1. An order cannot be placed while it has no lines.
2. Total is calculated from the current lines.
3. Lines can be added or removed only while status is `DRAFT`.
4. Only valid lifecycle transitions are accepted.
5. Shipment metadata is created only by the guarded `ship` operation, which requires `PAID`.
6. Lines are keyed by `ProductId`; adding the same product merges quantities. A conflicting unit price for the same product is rejected.
7. `Money` prevents mixed-currency addition and `Quantity` must be positive.

## Compile and run (JDK 17+)
From the project root:
```powershell
javac -d bin src\*.java
java -cp bin App
```

## Case Study Exam Answers

### 1. Four contradictory states in the naive model
- `status = "DRAFT"` and `shipped = true` with `shippedAt` set: violates the lifecycle and shipment/status consistency invariant.
- `cancelled = true` and `shipped = true`: violates the rule that shipped orders cannot be cancelled.
- `status = "SHIPPED"` with an empty `lines` list: violates the placed-order non-empty-lines invariant.
- `status = "PAID"` but `paid = false`: contradictory duplicate representations of payment state.
- `total` differs from the sum of line totals after a line edit: violates the total-equals-lines invariant.

### 2. State transition table and guarded ship method

| Current state | Allowed operation | Next state |
|---|---|---|
| DRAFT | place (only if at least one line) | PLACED |
| DRAFT | cancel | CANCELLED |
| PLACED | pay | PAID |
| PLACED | cancel | CANCELLED |
| PAID | ship (tracking number and timestamp required) | SHIPPED |
| PAID | cancel | CANCELLED |
| SHIPPED | deliver | DELIVERED |
| SHIPPED | cancel | Not allowed |
| DELIVERED | cancel | Not allowed |
| CANCELLED | Any lifecycle transition | Not allowed |

The `ship` method first checks that the current state is `PAID`. If the order is `CANCELLED`, the guard fails and throws `DomainException` before shipment data or status can be changed. A cancelled order therefore cannot be shipped.

### 3. Model A vs Model B
- **Type safety:** Model A checks transitions at runtime and throws domain exceptions. Model B represents each state with a separate type, so unavailable operations (such as cancelling a shipped order) are absent from that type's API and invalid transitions can become compile-time errors.
- **Code volume:** Model A has lower code volume and centralizes lifecycle logic. Model B needs more classes and transition-return types.
- **Persistence:** Model A is simpler to map because one entity stores a status and optional state-specific data. Model B needs a discriminator and state-specific mapping.
- **Recommendation for eight frequently changing states:** Model A. The source case study recommends Model A for many states and frequent change with simple needs. Its guarded transition methods are easier to evolve without creating many state classes.

### 4. Why derive total instead of storing it?
A derived total cannot become stale when a line is added, removed, or its quantity changes. Storing a total may be justified for a high-volume reporting or historical snapshot requirement. If stored, an extra invariant is required: the stored total must always equal the sum of all order-line totals, and every line mutation must update both atomically.

### 5. Credit-limit rule and concurrent orders
The customer's credit limit is not an Order invariant because credit belongs to the Customer or Credit aggregate, not to the Order aggregate. Enforce it in an application-layer workflow or domain service that coordinates the customer credit check and order placement. To prevent two simultaneous orders from both spending the same remaining credit, use an atomic reservation/authorization against the customer's credit balance, implemented with a database transaction, row lock, or optimistic concurrency/version check. Only place the order after the reservation succeeds; release or compensate the reservation if placement fails. This is a cross-aggregate consistency rule, not an invariant owned by Order.

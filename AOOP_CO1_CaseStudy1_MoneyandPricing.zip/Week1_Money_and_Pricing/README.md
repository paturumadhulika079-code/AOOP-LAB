# Week 1 – Money and Pricing Case Study

## Overview
This Java OOP case study demonstrates money and pricing concepts for an e-commerce catalog.

## Source files
- `Currency.java` – Defines supported currencies and their minor-unit precision.
- `CurrencyMismatch.java` – Custom exception for operations involving different currencies.
- `Money.java` – Represents non-negative monetary values and supports addition, quantity multiplication, and discount subtraction.
- `Percentage.java` – Represents a percentage using basis points and applies a discount to a Money value.
- `Quantity.java` – Represents a positive quantity and supports addition and subtraction.
- `Main.java` – Demonstrates the classes and validation/error cases.

## Requirements
- Java JDK installed
- Terminal or command prompt

## Compile
Open a terminal in this folder and run:

```bash
javac Currency.java CurrencyMismatch.java Money.java Percentage.java Quantity.java Main.java
```

## Run

```bash
java Main
```

## Expected output

```text
Original Price: USD 1000.00
Discount: 20.0%
Discounted Price: USD 800.00
Quantity: 2
Final Total: USD 1600.00
Invalid quantity rejected
Invalid discount rejected
Currency mismatch rejected
```

## Notes
Compiled `.class` files are excluded from version control by `.gitignore`. The repository contains the Java source code and this README so the implementation can be reviewed and compiled.
